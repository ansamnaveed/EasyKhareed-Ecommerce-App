
class AddonConfig{
  static bool club_point_addon_installed = true;
  static bool refund_addon_installed = true;
  static bool otp_addon_installed = false;

}