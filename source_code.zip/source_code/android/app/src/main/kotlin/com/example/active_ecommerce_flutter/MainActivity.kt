package com.einnovention.easy_khareed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
